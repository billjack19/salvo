<?php
$_REQUEST['submitted'] = 1;
$_REQUEST['mail_to'] = 'jackbiller19@gmail.com';
$_REQUEST['mail_from'] = 'jackmailteste@gmail.com';
$_REQUEST['mail_cc'] = 'cdiinfo.suporte@gmail.com';
$_REQUEST['mail_host'] = 'smtp.gmail.com';
$_REQUEST['mail_port'] = 587;