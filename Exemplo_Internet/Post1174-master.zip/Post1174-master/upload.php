<?php

// Apenas retornando o que foi recebido
echo json_encode($_FILES);