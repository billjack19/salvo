Facilitando requisições AJAX com jQuery Form Plugin

Mais informações: http://rafaelcouto.com.br/facilitando-requisicoes-ajax-com-jquery-form-plugin/
